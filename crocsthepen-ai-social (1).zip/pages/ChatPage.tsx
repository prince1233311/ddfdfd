
import React, { useState, useRef, useEffect } from 'react';
import { Link, useParams, useNavigate, useSearchParams } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { User, Message, MessagePart, ChatMode, ChatSession } from '../types';
import { generateAIResponseStream, generateImage, generateSpeech, playAudio } from '../services/geminiService';
import { Logo, COST_PER_MESSAGE, COST_PER_IMAGE, APP_NAME } from '../constants.tsx';
import { GenerateContentResponse } from "@google/genai";

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

interface ChatPageProps {
  user: User;
  updateCredits: (balance: number) => void;
}

const ChatPage: React.FC<ChatPageProps> = ({ user, updateCredits }) => {
  const { mode = 'general' } = useParams<{ mode: string }>();
  const [searchParams] = useSearchParams();
  const sessionIdParam = searchParams.get('session');
  const chatMode = mode as ChatMode;
  
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(sessionIdParam);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<{file: File, base64: string, type: 'image'}[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isCalling, setIsCalling] = useState(false);
  const [recipient, setRecipient] = useState<User | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.onresult = (event: any) => {
        setInputValue(prev => prev + event.results[0][0].transcript);
        setIsListening(false);
      };
    }
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem(`croc_sessions_${user.id}`);
    if (saved) {
      const parsed: ChatSession[] = JSON.parse(saved);
      setSessions(parsed);
      const current = parsed.find(s => s.id === (sessionIdParam || activeSessionId));
      if (current) {
        setMessages(current.messages);
        setActiveSessionId(current.id);
        if (current.recipientId) {
          const users: User[] = JSON.parse(localStorage.getItem('croc_registered_users') || '[]');
          setRecipient(users.find(u => u.id === current.recipientId) || null);
        }
      } else {
        handleNewChat(parsed);
      }
    } else {
      handleNewChat([]);
    }
  }, [user.id, chatMode, sessionIdParam]);

  const saveSessions = (updatedSessions: ChatSession[]) => {
    setSessions(updatedSessions);
    localStorage.setItem(`croc_sessions_${user.id}`, JSON.stringify(updatedSessions));
  };

  const handleNewChat = (currentSessions = sessions) => {
    const newId = Date.now().toString();
    const newSession: ChatSession = {
      id: newId,
      title: "New Chat",
      mode: chatMode,
      messages: [],
      updatedAt: Date.now()
    };
    const updated = [newSession, ...currentSessions];
    saveSessions(updated);
    setActiveSessionId(newId);
    setMessages([]);
  };

  // Fixed handleFileUpload: explicitly typed 'file' as File to resolve unknown type error on line 104
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (ev) => setAttachedFiles(prev => [...prev, { file, base64: (ev.target?.result as string).split(',')[1], type: 'image' }]);
      reader.readAsDataURL(file);
    });
  };

  const startVideoCall = async () => {
    setIsCalling(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (e) {
      alert("Could not access camera");
      setIsCalling(false);
    }
  };

  const handleSend = async () => {
    if (isLoading || !activeSessionId) return;
    const prompt = inputValue.trim();
    if (!prompt && attachedFiles.length === 0) return;

    setIsLoading(true);
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: prompt, timestamp: Date.now(), parts: attachedFiles.map(f => ({ imageUrl: `data:image/png;base64,${f.base64}` })) };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInputValue('');
    setAttachedFiles([]);

    const aiMsgId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, { id: aiMsgId, role: 'assistant', content: '...', timestamp: Date.now(), isGenerating: true }]);

    try {
      if (chatMode === 'social' || recipient) {
        // Simulated real-time response for social chat
        setTimeout(() => {
          const reply = "That's awesome! Check this out.";
          setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, content: reply, isGenerating: false } : m));
          saveSessions(sessions.map(s => s.id === activeSessionId ? { ...s, messages: [...newMessages, { id: aiMsgId, role: 'assistant', content: reply, timestamp: Date.now() }] } : s));
        }, 1500);
      } else {
        const stream = await generateAIResponseStream(prompt, messages, chatMode);
        let text = '';
        for await (const chunk of stream) {
          // Cast chunk to GenerateContentResponse and use .text property as per guidelines
          const c = chunk as GenerateContentResponse;
          text += c.text;
          setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, content: text, isGenerating: false } : m));
        }
        updateCredits(user.credits - COST_PER_MESSAGE);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-64px)] bg-white text-gray-900 overflow-hidden font-['Plus_Jakarta_Sans']">
      <div className={`${isSidebarOpen ? 'flex' : 'hidden'} md:flex w-72 flex-col bg-gray-50 border-r border-gray-100 p-4 shrink-0 transition-all`}>
        <button onClick={() => handleNewChat()} className="p-4 mb-6 rounded-2xl bg-white border border-gray-100 hover:border-emerald-500 transition-all font-bold text-sm flex items-center gap-3 shadow-sm"><i className="fa-solid fa-plus text-emerald-600"></i> New Conversation</button>
        <div className="flex-1 overflow-y-auto space-y-2">
          {sessions.filter(s => s.mode === chatMode).map(s => (
            <div key={s.id} onClick={() => { setActiveSessionId(s.id); setMessages(s.messages); }} className={`p-3 rounded-xl cursor-pointer transition-all flex items-center gap-3 ${activeSessionId === s.id ? 'bg-white border border-gray-200 shadow-md' : 'hover:bg-gray-100'}`}>
              <i className="fa-solid fa-message text-[10px] text-gray-300"></i>
              <span className="text-xs font-bold truncate">{s.title}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col relative">
        <header className="px-6 py-4 border-b border-gray-50 flex items-center justify-between bg-white/80 backdrop-blur-md sticky top-0 z-20">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-gray-400 hover:text-emerald-600 md:hidden"><i className="fa-solid fa-bars"></i></button>
            {recipient ? (
              <div className="flex items-center gap-3">
                <img src={recipient.avatar} className="w-8 h-8 rounded-full border border-gray-200" alt="" />
                <div>
                  <h3 className="text-sm font-black text-gray-900">{recipient.username}</h3>
                  <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest">{recipient.status}</p>
                </div>
              </div>
            ) : (
              <h1 className="text-xs font-black text-gray-400 uppercase tracking-widest">{chatMode} HUB</h1>
            )}
          </div>
          <div className="flex items-center gap-3">
            {recipient && (
              <button onClick={startVideoCall} className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-all"><i className="fa-solid fa-video"></i></button>
            )}
            <div className="bg-emerald-50 px-4 py-2 rounded-xl text-emerald-600 font-black text-sm">{user.credits} CR</div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map(msg => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} fade-in`}>
              <div className={`max-w-[75%] p-4 rounded-[28px] shadow-sm ${msg.role === 'user' ? 'bg-gray-900 text-white rounded-tr-none' : 'bg-gray-50 border border-gray-100 text-gray-800 rounded-tl-none'}`}>
                {msg.content}
                {msg.parts?.map((p, i) => p.imageUrl && <img key={i} src={p.imageUrl} className="mt-3 rounded-xl max-w-full" alt="" />)}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-6 bg-white border-t border-gray-50">
          <div className="max-w-4xl mx-auto flex items-center gap-3 relative">
            {attachedFiles.length > 0 && <div className="absolute -top-16 left-0 flex gap-2">{attachedFiles.map((f, i) => <img key={i} src={`data:image/png;base64,${f.base64}`} className="w-12 h-12 rounded-lg border border-gray-200 shadow-sm" alt="" />)}</div>}
            <button onClick={() => fileInputRef.current?.click()} className="w-12 h-12 bg-gray-50 text-gray-400 rounded-2xl flex items-center justify-center hover:bg-emerald-50 hover:text-emerald-600 transition-all"><i className="fa-solid fa-image"></i></button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" multiple onChange={handleFileUpload} />
            <input type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} placeholder="Type a message..." className="flex-1 bg-gray-50 border border-gray-100 rounded-[28px] px-6 py-4 focus:ring-4 focus:ring-emerald-500/10 outline-none font-medium" />
            <button onClick={handleSend} disabled={isLoading || (!inputValue.trim() && attachedFiles.length === 0)} className="w-14 h-14 bg-emerald-600 text-white rounded-[28px] flex items-center justify-center shadow-lg shadow-emerald-200 hover:bg-emerald-500 transition-all"><i className="fa-solid fa-paper-plane"></i></button>
          </div>
        </div>
      </div>

      {isCalling && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center">
          <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
          <div className="absolute bottom-12 flex gap-6">
             <button onClick={() => setIsCalling(false)} className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center text-2xl shadow-2xl"><i className="fa-solid fa-phone-slash"></i></button>
          </div>
          <div className="absolute top-12 left-12 flex items-center gap-4 bg-black/40 p-4 rounded-3xl backdrop-blur-xl">
             <img src={recipient?.avatar} className="w-12 h-12 rounded-full" alt="" />
             <div className="text-white"><h3 className="font-black">Calling {recipient?.username}...</h3><p className="text-xs opacity-60">Connecting via CrocNet</p></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatPage;
