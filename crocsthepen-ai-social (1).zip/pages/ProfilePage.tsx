
import React, { useRef, useState } from 'react';
import { User } from '../types';
import { APP_NAME } from '../constants.tsx';

interface ProfilePageProps {
  user: User;
  logout: () => void;
  onRefill: () => void;
  onUpdateUser: (updatedUser: Partial<User>) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user, logout, onUpdateUser }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newUsername, setNewUsername] = useState(user.username);
  const [newPassword, setNewPassword] = useState((user as any).password || '');
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => onUpdateUser({ avatar: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    setIsSaving(true);
    setMessage('');
    setTimeout(() => {
      onUpdateUser({ username: newUsername, password: newPassword } as any);
      setIsSaving(false);
      setMessage('Profile updated successfully!');
      setTimeout(() => setMessage(''), 3000);
    }, 1000);
  };

  return (
    <div className="flex-1 max-w-6xl mx-auto w-full px-6 py-16 slide-up">
      <div className="bg-white rounded-[40px] border border-gray-100 overflow-hidden shadow-2xl shadow-gray-200">
        <div className="h-56 bg-gradient-to-br from-emerald-500 to-green-400 relative">
           <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
           <div className="absolute -bottom-20 left-12 group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              <div className="relative">
                <img src={user.avatar} alt="Profile" className="w-40 h-40 rounded-[34px] border-4 border-gray-50 object-cover bg-white" />
                <div className="absolute inset-0 bg-black/40 rounded-[34px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all border-4 border-transparent">
                  <i className="fa-solid fa-camera text-white text-2xl"></i>
                </div>
              </div>
           </div>
           <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
        </div>

        <div className="pt-24 pb-12 px-12">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              <div className="space-y-8">
                <div>
                  <h2 className="text-4xl font-black text-gray-900 tracking-tight mb-2">Account Settings</h2>
                  <p className="text-gray-400 font-medium">Update your account information</p>
                </div>
                
                {message && <div className="p-4 bg-emerald-50 text-emerald-600 rounded-2xl text-xs font-black uppercase tracking-widest border border-emerald-100 animate-fadeIn">{message}</div>}

                <div className="space-y-6">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Username</label>
                    <input type="text" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} className="w-full bg-gray-50 border border-gray-100 px-6 py-4 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all font-bold" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Password</label>
                    <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="w-full bg-gray-50 border border-gray-100 px-6 py-4 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all font-bold" />
                  </div>
                  <button onClick={handleSave} disabled={isSaving} className="w-full bg-gray-900 hover:bg-emerald-600 text-white font-black py-4 rounded-2xl transition-all shadow-xl disabled:opacity-50">
                    {isSaving ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </div>

              <div className="p-10 bg-gray-50 border border-gray-100 rounded-[40px] flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-black text-gray-900 mb-8 flex items-center"><i className="fa-solid fa-bolt mr-4 text-emerald-600"></i> Balance</h3>
                  <div className="text-6xl font-black text-gray-900 mb-4">{user.credits} <span className="text-xs font-black text-gray-400 ml-2 uppercase tracking-widest">CR</span></div>
                  <p className="text-gray-500 font-medium text-sm">Credits power your creations. Complete daily tasks to earn more.</p>
                </div>
                <button onClick={logout} className="mt-8 px-8 py-4 bg-white hover:bg-red-50 text-red-500 border border-red-100 rounded-2xl transition-all font-black text-sm flex items-center justify-center">
                  <i className="fa-solid fa-power-off mr-3"></i> Sign Out
                </button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
