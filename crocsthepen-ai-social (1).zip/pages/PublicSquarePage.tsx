
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, ChatSession } from '../types';

interface PublicSquarePageProps {
  user: User;
  onUserUpdate: (updatedUser: Partial<User>) => void;
}

const PublicSquarePage: React.FC<PublicSquarePageProps> = ({ user, onUserUpdate }) => {
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'requests'>('all');
  const navigate = useNavigate();

  useEffect(() => {
    refreshUsers();
  }, [user.id]);

  const refreshUsers = () => {
    const list: User[] = JSON.parse(localStorage.getItem('croc_registered_users') || '[]');
    setAllUsers(list);
  };

  const handleAddFriend = (targetId: string) => {
    const users: User[] = JSON.parse(localStorage.getItem('croc_registered_users') || '[]');
    const currentUser = users.find(u => u.id === user.id);
    const targetUser = users.find(u => u.id === targetId);

    if (currentUser && targetUser) {
      if (!currentUser.friendRequestsSent) currentUser.friendRequestsSent = [];
      if (!targetUser.friendRequestsReceived) targetUser.friendRequestsReceived = [];

      if (!currentUser.friendRequestsSent.includes(targetId)) {
        currentUser.friendRequestsSent.push(targetId);
      }
      if (!targetUser.friendRequestsReceived.includes(user.id)) {
        targetUser.friendRequestsReceived.push(user.id);
      }

      localStorage.setItem('croc_registered_users', JSON.stringify(users));
      onUserUpdate(currentUser);
      refreshUsers();
    }
  };

  const handleAcceptRequest = (targetId: string) => {
    const users: User[] = JSON.parse(localStorage.getItem('croc_registered_users') || '[]');
    const currentUser = users.find(u => u.id === user.id);
    const targetUser = users.find(u => u.id === targetId);

    if (currentUser && targetUser) {
      if (!currentUser.friends) currentUser.friends = [];
      if (!targetUser.friends) targetUser.friends = [];

      // Add to friends
      if (!currentUser.friends.includes(targetId)) currentUser.friends.push(targetId);
      if (!targetUser.friends.includes(user.id)) targetUser.friends.push(user.id);

      // Remove from requests
      currentUser.friendRequestsReceived = (currentUser.friendRequestsReceived || []).filter(id => id !== targetId);
      targetUser.friendRequestsSent = (targetUser.friendRequestsSent || []).filter(id => id !== user.id);

      localStorage.setItem('croc_registered_users', JSON.stringify(users));
      onUserUpdate(currentUser);
      refreshUsers();
    }
  };

  const handleDeclineRequest = (targetId: string) => {
    const users: User[] = JSON.parse(localStorage.getItem('croc_registered_users') || '[]');
    const currentUser = users.find(u => u.id === user.id);
    const targetUser = users.find(u => u.id === targetId);

    if (currentUser && targetUser) {
      currentUser.friendRequestsReceived = (currentUser.friendRequestsReceived || []).filter(id => id !== targetId);
      targetUser.friendRequestsSent = (targetUser.friendRequestsSent || []).filter(id => id !== user.id);

      localStorage.setItem('croc_registered_users', JSON.stringify(users));
      onUserUpdate(currentUser);
      refreshUsers();
    }
  };

  const startChat = (targetUser: User) => {
    const sessions: ChatSession[] = JSON.parse(localStorage.getItem(`croc_sessions_${user.id}`) || '[]');
    const existing = sessions.find(s => s.recipientId === targetUser.id);

    if (existing) {
      navigate(`/chat/social?session=${existing.id}`);
    } else {
      const newSession: ChatSession = {
        id: `social_${Date.now()}`,
        title: `Chat with ${targetUser.username}`,
        mode: 'social',
        messages: [],
        updatedAt: Date.now(),
        recipientId: targetUser.id
      };
      localStorage.setItem(`croc_sessions_${user.id}`, JSON.stringify([newSession, ...sessions]));
      navigate(`/chat/social?session=${newSession.id}`);
    }
  };

  const otherUsers = allUsers.filter(u => u.id !== user.id);
  const requestsReceived = otherUsers.filter(u => user.friendRequestsReceived?.includes(u.id));
  const filteredAll = otherUsers.filter(u => u.username.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex-1 bg-white p-6 md:p-12 fade-in">
      <div className="max-w-6xl mx-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-black text-gray-900 tracking-tight">Public Square</h1>
            <p className="text-gray-500 font-medium">Connect with friends to start chatting.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex bg-gray-100 p-1 rounded-2xl">
              <button 
                onClick={() => setActiveTab('all')}
                className={`px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'all' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                Find People
              </button>
              <button 
                onClick={() => setActiveTab('requests')}
                className={`px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all relative ${activeTab === 'requests' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                Requests
                {requestsReceived.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-white text-[8px] rounded-full flex items-center justify-center animate-pulse">
                    {requestsReceived.length}
                  </span>
                )}
              </button>
            </div>
            {activeTab === 'all' && (
              <div className="relative w-64">
                <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-300"></i>
                <input 
                  type="text" 
                  placeholder="Search..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl pl-10 pr-4 py-3 text-sm focus:border-emerald-500 outline-none transition-all"
                />
              </div>
            )}
          </div>
        </header>

        {activeTab === 'all' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAll.length === 0 ? (
              <div className="col-span-full py-20 text-center opacity-30">
                 <i className="fa-solid fa-user-group text-6xl mb-4"></i>
                 <p className="font-bold">No community members found.</p>
              </div>
            ) : (
              filteredAll.map((u, idx) => {
                const isFriend = user.friends?.includes(u.id);
                const isSent = user.friendRequestsSent?.includes(u.id);
                const isReceived = user.friendRequestsReceived?.includes(u.id);

                return (
                  <div 
                    key={u.id} 
                    className="bg-white border border-gray-100 p-6 rounded-[32px] hover:shadow-2xl hover:shadow-emerald-500/5 transition-all group slide-up"
                    style={{ animationDelay: `${idx * 0.05}s` }}
                  >
                    <div className="flex items-center space-x-5 mb-6">
                      <div className="relative">
                        <img src={u.avatar} alt={u.username} className="w-16 h-16 rounded-2xl object-cover bg-gray-50" />
                      </div>
                      <div>
                        <h3 className="font-black text-lg text-gray-900 group-hover:text-emerald-600 transition-colors">{u.username}</h3>
                        <p className="text-[10px] font-black uppercase tracking-widest text-emerald-600">
                          {isFriend ? 'Friend' : 'Member'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      {isFriend ? (
                        <button 
                          onClick={() => startChat(u)}
                          className="w-full py-3.5 bg-gray-900 hover:bg-emerald-600 text-white rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-lg hover:shadow-emerald-500/20"
                        >
                          Message
                        </button>
                      ) : isSent ? (
                        <button disabled className="w-full py-3.5 bg-gray-50 text-gray-400 rounded-xl text-xs font-black uppercase tracking-widest cursor-default">
                          Request Sent
                        </button>
                      ) : isReceived ? (
                        <button 
                          onClick={() => handleAcceptRequest(u.id)}
                          className="w-full py-3.5 bg-emerald-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-100"
                        >
                          Accept Request
                        </button>
                      ) : (
                        <button 
                          onClick={() => handleAddFriend(u.id)}
                          className="w-full py-3.5 bg-white border border-gray-200 text-gray-900 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-600 rounded-xl text-xs font-black uppercase tracking-widest transition-all"
                        >
                          Add Friend
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          <div className="max-w-2xl mx-auto space-y-4">
            {requestsReceived.length === 0 ? (
              <div className="py-20 text-center opacity-30">
                 <i className="fa-solid fa-envelope-open text-6xl mb-4"></i>
                 <p className="font-bold">No pending requests.</p>
              </div>
            ) : (
              requestsReceived.map((u, idx) => (
                <div 
                  key={u.id}
                  className="bg-white border border-gray-100 p-6 rounded-[32px] flex items-center justify-between slide-up"
                  style={{ animationDelay: `${idx * 0.05}s` }}
                >
                  <div className="flex items-center space-x-4">
                    <img src={u.avatar} alt={u.username} className="w-12 h-12 rounded-xl object-cover bg-gray-50" />
                    <div>
                      <h3 className="font-black text-gray-900">{u.username}</h3>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Wants to be your friend</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button 
                      onClick={() => handleDeclineRequest(u.id)}
                      className="px-4 py-2 bg-gray-50 text-gray-400 hover:text-red-500 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                    >
                      Decline
                    </button>
                    <button 
                      onClick={() => handleAcceptRequest(u.id)}
                      className="px-6 py-2 bg-emerald-600 text-white hover:bg-emerald-500 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-emerald-100"
                    >
                      Accept
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PublicSquarePage;
