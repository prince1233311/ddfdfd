
import { GoogleGenAI, GenerateContentResponse, Part, Modality } from "@google/genai";
import { ChatMode, MessagePart } from "../types";

// Manual base64 decoding implementation as required by guidelines
const decodeBase64 = (base64: string) => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

// Raw PCM decoding implementation as required by Gemini TTS guidelines for headerless audio
async function decodeRawPcm(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const getAI = () => {
  // Always use process.env.API_KEY directly as required by the coding guidelines
  const apiKey = process.env.API_KEY;
  if (!apiKey || apiKey.trim() === '') throw new Error("API_KEY_MISSING");
  return new GoogleGenAI({ apiKey });
};

const transformPart = (part: MessagePart): Part | null => {
  if (part.text) return { text: part.text };
  if (part.inlineData && part.inlineData.data) {
    const cleanData = part.inlineData.data.includes(',') ? part.inlineData.data.split(',')[1] : part.inlineData.data;
    if (!cleanData) return null;
    return { inlineData: { mimeType: part.inlineData.mimeType, data: cleanData } };
  }
  return null;
};

export const generateAIResponseStream = async (prompt: string, history: any[], mode: ChatMode = 'general', parts: MessagePart[] = []) => {
  const ai = getAI();
  const sanitizedHistory = history.map(h => {
    let msgParts: Part[] = [];
    if (h.parts && h.parts.length > 0) {
      msgParts = (h.parts as MessagePart[]).map(transformPart).filter(p => p !== null) as Part[];
    } else if (h.content) {
      msgParts = [{ text: h.content }];
    }
    return {
      role: h.role === 'assistant' ? 'model' : 'user',
      parts: msgParts
    };
  }).filter(h => h.parts.length > 0);

  const currentParts = parts.map(transformPart).filter(p => p !== null) as Part[];
  if (currentParts.length === 0 && prompt) currentParts.push({ text: prompt });

  const model = (mode === 'code') ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';

  try {
    return await ai.models.generateContentStream({
      model,
      contents: [...sanitizedHistory, { role: 'user', parts: currentParts }],
      config: { temperature: 0.7 }
    });
  } catch (error: any) {
    if (error.status === 429) throw new Error("Server is currently busy. Please try again in 30 seconds.");
    throw error;
  }
};

// Fixed missing exported member generateWebsiteStream for WebsiteBuilderPage.tsx
export const generateWebsiteStream = async (prompt: string, history: any[]) => {
  const ai = getAI();
  const sanitizedHistory = history.map(h => ({
    role: h.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: h.content }]
  })).filter(h => h.parts[0].text);

  return await ai.models.generateContentStream({
    model: 'gemini-3-pro-preview', // Complex reasoning for high-quality web architecture
    contents: sanitizedHistory,
    config: {
      systemInstruction: "You are a world-class senior frontend engineer and web architect. Build professional single-page applications using HTML, Tailwind CSS, and Font Awesome. Always return code in a markdown block tagged with html.",
      temperature: 0.7
    }
  });
};

export const generateImage = async (prompt: string, aspectRatio: "1:1" | "16:9" | "9:16" = "1:1") => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image', 
      contents: { parts: [{ text: `High quality masterpiece, 4k, cinematic: ${prompt}` }] },
      config: { imageConfig: { aspectRatio } }
    });
    const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
    if (!part?.inlineData) throw new Error("Generation failed");
    return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
  } catch (error: any) {
    if (error.status === 429) throw new Error("Image Studio quota reached. Try again in 60s.");
    throw error;
  }
};

export const generateVideoAnimation = async (prompt: string, characterBase64?: string, videoBase64?: string, aspectRatio: '16:9' | '9:16' = '16:9') => {
  const ai = getAI();
  
  const config: any = {
    model: 'veo-3.1-fast-generate-preview',
    prompt: prompt || "Animate this character naturally",
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: aspectRatio
    }
  };

  if (characterBase64) {
    config.image = {
      imageBytes: characterBase64.split(',')[1] || characterBase64,
      mimeType: 'image/png'
    };
  }

  let operation = await ai.models.generateVideos(config);

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000)); // Poll every 10 seconds as per guidelines
    operation = await ai.operations.getVideosOperation({ operation });
  }

  const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!videoUri) throw new Error("No video produced");

  // Always use process.env.API_KEY directly for model-generated content downloads
  const response = await fetch(`${videoUri}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  return URL.createObjectURL(blob);
};

export const generateSpeech = async (text: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
};

// Fixed playAudio to use correct raw PCM decoding for Gemini TTS output
export const playAudio = async (base64Audio: string) => {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const bytes = decodeBase64(base64Audio);
  // Manual raw PCM decoding (24kHz, mono) as specified in guidelines
  const audioBuffer = await decodeRawPcm(bytes, audioContext, 24000, 1);
  const source = audioContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(audioContext.destination);
  source.start(0);
};
