
export type ChatMode = 'general' | 'image' | 'code' | 'social';

export interface User {
  id: string;
  username: string;
  email: string;
  avatar: string;
  credits: number;
  lastDailyClaim?: number;
  tasksCompleted?: string[];
  status?: 'online' | 'offline' | 'busy';
  bio?: string;
  friends?: string[]; // Array of User IDs
  friendRequestsReceived?: string[]; // Array of User IDs
  friendRequestsSent?: string[]; // Array of User IDs
}

export interface MessagePart {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
  };
  fileData?: {
    mimeType: string;
    fileUri: string;
  };
  videoUrl?: string;
  imageUrl?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  parts?: MessagePart[];
  timestamp: number;
  isGenerating?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  mode: ChatMode;
  messages: Message[];
  updatedAt: number;
  recipientId?: string; // For private chats
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}
