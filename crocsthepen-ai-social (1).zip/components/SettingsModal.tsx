
import React from 'react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm fade-in">
      <div className="bg-white rounded-[32px] p-8 w-full max-w-md shadow-2xl scale-in border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-gray-900">Settings</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center hover:bg-gray-100 transition-colors">
            <i className="fa-solid fa-xmark text-gray-400"></i>
          </button>
        </div>
        
        <div className="mb-8">
          <p className="text-xs text-gray-500 leading-relaxed font-medium bg-emerald-50/50 p-4 rounded-xl border border-emerald-100 text-emerald-800">
            <i className="fa-solid fa-circle-info mr-2"></i>
            Application configuration is managed securely by the platform. You have full access to all features.
          </p>
        </div>
        
        <div className="flex justify-end space-x-3">
          <button onClick={onClose} className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-black shadow-lg shadow-emerald-200 transition-all transform hover:scale-105 active:scale-95">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
