
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { User, AuthState, ChatMode } from './types';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import ChatPage from './pages/ChatPage';
import DashboardPage from './pages/DashboardPage';
import ProfilePage from './pages/ProfilePage';
import DailyRewardsPage from './pages/DailyRewardsPage';
import WebsiteBuilderPage from './pages/WebsiteBuilderPage';
import PublicSquarePage from './pages/PublicSquarePage';
import Navbar from './components/Navbar';
import SettingsModal from './components/SettingsModal';

const App: React.FC = () => {
  const [auth, setAuth] = useState<AuthState>({
    user: null,
    isAuthenticated: false
  });
  const [isLoaded, setIsLoaded] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('croc_user');
    if (storedUser) {
      try {
        const parsed = JSON.parse(storedUser);
        // Ensure user has friend properties
        if (!parsed.friends) parsed.friends = [];
        if (!parsed.friendRequestsReceived) parsed.friendRequestsReceived = [];
        if (!parsed.friendRequestsSent) parsed.friendRequestsSent = [];
        setAuth({ user: parsed, isAuthenticated: true });
      } catch (e) {}
    }
    setIsLoaded(true);
  }, []);

  const login = (user: User) => {
    localStorage.setItem('croc_user', JSON.stringify(user));
    setAuth({ user, isAuthenticated: true });
  };

  const logout = () => {
    localStorage.removeItem('croc_user');
    setAuth({ user: null, isAuthenticated: false });
  };

  const updateCredits = (newBalance: number, lastClaim?: number, tasks?: string[]) => {
    if (auth.user) {
      const updatedUser = { 
        ...auth.user, 
        credits: newBalance,
        lastDailyClaim: lastClaim !== undefined ? lastClaim : auth.user.lastDailyClaim,
        tasksCompleted: tasks !== undefined ? tasks : (auth.user.tasksCompleted || [])
      };
      saveUserGlobally(updatedUser);
    }
  };

  const updateUser = (updatedUserPart: Partial<User>) => {
    if (auth.user) {
      const updatedUser = { ...auth.user, ...updatedUserPart };
      saveUserGlobally(updatedUser);
    }
  };

  const saveUserGlobally = (updatedUser: User) => {
    localStorage.setItem('croc_user', JSON.stringify(updatedUser));
    const users: User[] = JSON.parse(localStorage.getItem('croc_registered_users') || '[]');
    const userIndex = users.findIndex(u => u.id === updatedUser.id);
    if (userIndex !== -1) {
      users[userIndex] = updatedUser;
      localStorage.setItem('croc_registered_users', JSON.stringify(users));
    }
    setAuth({ user: updatedUser, isAuthenticated: true });
  };

  if (!isLoaded) return null;

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col bg-white">
        <Navbar auth={auth} logout={logout} onOpenSettings={() => setIsSettingsOpen(true)} />
        <main className="flex-1 flex flex-col">
          <Routes>
            <Route path="/" element={<LandingPage auth={auth} />} />
            <Route path="/login" element={!auth.isAuthenticated ? <LoginPage onLogin={login} /> : <Navigate to="/dashboard" />} />
            <Route path="/signup" element={!auth.isAuthenticated ? <SignupPage onSignup={login} /> : <Navigate to="/dashboard" />} />
            <Route path="/dashboard" element={auth.isAuthenticated ? <DashboardPage user={auth.user!} /> : <Navigate to="/login" />} />
            <Route path="/chat/:mode" element={auth.isAuthenticated ? <ChatPage user={auth.user!} updateCredits={updateCredits} /> : <Navigate to="/login" />} />
            <Route path="/builder" element={auth.isAuthenticated ? <WebsiteBuilderPage user={auth.user!} updateCredits={updateCredits} /> : <Navigate to="/login" />} />
            <Route path="/square" element={auth.isAuthenticated ? <PublicSquarePage user={auth.user!} onUserUpdate={updateUser} /> : <Navigate to="/login" />} />
            <Route path="/profile" element={auth.isAuthenticated ? <ProfilePage user={auth.user!} logout={logout} onRefill={() => {}} onUpdateUser={updateUser} /> : <Navigate to="/login" />} />
            <Route path="/rewards" element={auth.isAuthenticated ? (
              <DailyRewardsPage user={auth.user!} onClaim={() => updateCredits(auth.user!.credits + 40, Date.now())} onTaskComplete={(id, r) => {
                const tasks = auth.user?.tasksCompleted || [];
                if (!tasks.includes(id)) updateCredits(auth.user!.credits + r, auth.user?.lastDailyClaim, [...tasks, id]);
              }} />
            ) : <Navigate to="/login" />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
        <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      </div>
    </HashRouter>
  );
};

export default App;
